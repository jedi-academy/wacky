-- phpMyAdmin SQL Dump
-- version 4.6.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 04, 2017 at 12:13 AM
-- Server version: 5.7.18
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wacky`
--

-- --------------------------------------------------------

--
-- Table structure for table `airlines`
--

DROP TABLE IF EXISTS `airlines`;
CREATE TABLE `airlines` (
  `id` varchar(16) NOT NULL,
  `base` varchar(3) NOT NULL,
  `dest1` varchar(3) NOT NULL,
  `dest2` varchar(3) NOT NULL,
  `dest3` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `airlines`
--

INSERT INTO `airlines` (`id`, `base`, `dest1`, `dest2`, `dest3`) VALUES
('albatros', 'YBL', 'YAL', 'YZT', 'YMP'),
('bluebird', 'YCD', 'YQQ', 'YAZ', 'YPB'),
('cuckoo', 'YCG', 'ZGF', 'YCW', 'ZMH'),
('dove', 'YCW', 'YSE', 'YPB', 'YXT'),
('eagle', 'YDQ', 'YXJ', 'YNH', 'YCQ'),
('falcon', 'YDT', 'YCD', 'ZGF', 'YXC'),
('goose', 'YGE', 'ZMH', 'YYJ', 'YVE'),
('heron', 'YKA', 'YGE', 'YBD', 'YSE'),
('ibis', 'YLW', 'YCP', 'YAA', 'YCG'),
('junco', 'YPK', 'YCH', 'ZMH', 'YYF'),
('kite', 'YPR', 'ZMT', 'YZP', 'YXT'),
('loon', 'YPW', 'YBD', 'ZEL', 'YPU'),
('magpie', 'YQZ', 'YXS', 'YWL', 'YKA'),
('nuthatch', 'YRV', 'YCG', 'YMB', 'YCZ'),
('owl', 'YSN', 'YRV', 'YCZ', 'YVE'),
('pelican', 'YVR', 'YPR', 'YXS', 'YXC'),
('quail', 'YXC', 'YBD', 'YAZ', 'YCP'),
('raven', 'YXS', 'YPR', 'YDQ', 'YVR'),
('swallow', 'YXT', 'XQU', 'YYD', 'ZST'),
('thrush', 'YXX', 'YDT', 'YMB', 'YLW'),
('unlikely', 'YYD', 'YPZ', 'YDL', 'ZST'),
('vulture', 'YYE', 'YDL', 'YXJ', 'YXZ'),
('warbler', 'YYF', 'YHE', 'YKA', 'YXC'),
('xwing', 'YYJ', 'YBL', 'YVR', 'YPW'),
('yellowhammer', 'YZY', 'YQZ', 'ZEL', 'YGB'),
('zipper', 'ZMH', 'YVR', 'YXS', 'YPR');

-- --------------------------------------------------------

--
-- Table structure for table `airplanes`
--

DROP TABLE IF EXISTS `airplanes`;
CREATE TABLE `airplanes` (
  `id` varchar(16) NOT NULL,
  `manufacturer` varchar(32) NOT NULL,
  `model` varchar(32) NOT NULL,
  `price` int(11) NOT NULL,
  `seats` int(11) NOT NULL,
  `reach` int(11) NOT NULL,
  `cruise` int(11) NOT NULL,
  `takeoff` int(11) NOT NULL,
  `hourly` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `airplanes`
--

INSERT INTO `airplanes` (`id`, `manufacturer`, `model`, `price`, `seats`, `reach`, `cruise`, `takeoff`, `hourly`) VALUES
('avanti', 'Piaggo', 'Avanti II', 7195, 8, 2797, 589, 994, 977),
('baron', 'Beechcraft', 'Baron', 1350, 4, 1948, 373, 701, 340),
('caravan', 'Cessna', 'Grand Caravan EX', 2300, 14, 1689, 340, 660, 389),
('citation', 'Cessna', 'Citation M2', 3200, 7, 1550, 748, 978, 1122),
('kingair', 'Beechcraft', 'King Air C90', 3900, 12, 2446, 500, 1402, 990),
('mustang', 'Cessna', 'Citation Mustang', 2770, 4, 2130, 630, 950, 1015),
('pc12ng', 'Pilatus', 'PC-12 NG', 3300, 9, 4147, 500, 450, 727),
('phenom100', 'Embraer', 'Phenom 100', 2980, 4, 2148, 704, 1036, 926);

-- --------------------------------------------------------

--
-- Table structure for table `airports`
--

DROP TABLE IF EXISTS `airports`;
CREATE TABLE `airports` (
  `id` varchar(3) NOT NULL,
  `community` varchar(32) NOT NULL,
  `airport` varchar(64) NOT NULL,
  `region` int(11) NOT NULL,
  `coordinates` varchar(32) NOT NULL,
  `runway` int(11) NOT NULL,
  `airline` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `airports`
--

INSERT INTO `airports` (`id`, `community`, `airport`, `region`, `coordinates`, `runway`, `airline`) VALUES
('XQU', 'Qualicum Beach', 'Qualicum Beach Airport', 1, '49°20′14″N124°23′38″W', 1086, ''),
('YAA', 'Anahim Lake', 'Anahim Lake Airport', 5, '52°27′08″N125°18′16″W', 1200, ''),
('YAL', 'Alert Bay', 'Alert Bay Airport', 1, '50°34′56″N126°54′57″W', 910, ''),
('YAZ', 'Tofino', 'Tofino/Long Beach Airport', 1, '49°04′56″N125°46′21″W', 1524, ''),
('YBD', 'Bella Coola', 'Bella Coola Airport', 5, '52°23′15″N126°35′45″W', 1280, ''),
('YBL', 'Campbell River', 'Campbell River Airport', 1, '49°57′03″N125°16′15″W', 1981, 'albatros'),
('YCA', 'Courtenay', 'Courtenay Airpark', 1, '49°40′46″N124°58′54″W', 549, ''),
('YCD', 'Nanaimo', 'Nanaimo Airport', 1, '49°03′08″N123°52′13″W', 2012, 'bluebird'),
('YCG', 'Castlegar', 'Castlegar Airport', 4, '49°17′47″N117°37′57″W', 1615, 'cuckoo'),
('YCP', 'Blue River', 'Blue River Airport', 3, '52°07′27″N119°17′33″W', 1544, ''),
('YCQ', 'Chetwynd', 'Chetwynd Airport', 9, '55°41′14″N121°37′36″W', 1366, ''),
('YCW', 'Chilliwack', 'Chilliwack Airport', 2, '49°09′10″N121°56′20″W', 1215, 'dove'),
('YCZ', 'Fairmont Hot Springs', 'Fairmont Hot Springs Airport', 4, '50°19′49″N115°52′24″W', 1830, ''),
('YDL', 'Dease Lake', 'Dease Lake Airport', 6, '58°25′20″N130°01′56″W', 1830, ''),
('YDQ', 'Dawson Creek', 'Dawson Creek Airport', 9, '55°44′32″N120°10′59″W', 1524, 'eagle'),
('YDT', 'Delta', 'Boundary Bay Airport (Vancouver/Boundary Bay Airport)', 2, '49°04′26″N123°00′27″W', 1709, 'falcon'),
('YGB', 'Texada', 'Texada/Gillies Bay Airport', 2, '49°41′39″N124°31′04″W', 914, ''),
('YGE', 'Golden', 'Golden Airport', 4, '51°17′57″N116°58′57″W', 1380, 'goose'),
('YHE', 'Hope', 'Hope Aerodrome', 2, '49°22′06″N121°29′53″W', 1207, ''),
('YJM', 'Fort St. James', 'Fort St. James (Perison) Airport', 9, '54°23′50″N124°15′46″W', 1219, ''),
('YKA', 'Kamloops', 'Kamloops Airport', 3, '50°42′09″N120°26′55″W', 2438, 'heron'),
('YLW', 'Kelowna', 'Kelowna International Airport', 8, '49°57′26″N119°22′40″W', 2713, 'ibis'),
('YMB', 'Merritt', 'Merritt Airport (Saunders Field)', 3, '50°07′22″N120°44′42″W', 1220, ''),
('YMP', 'Port McNeill', 'Port McNeill Airport', 1, '50°34′32″N127°01′43″W', 732, ''),
('YNH', 'Hudson\'s Hope', 'Hudson\'s Hope Airport', 9, '56°02′08″N121°58′33″W', 1585, ''),
('YNJ', 'Langley', 'Langley Regional Airport', 2, '49°06′04″N122°37′50″W', 836, ''),
('YPB', 'Port Alberni', 'Port Alberni (Alberni Valley Regional) Airport', 1, '49°19′19″N124°55′52″W', 1205, ''),
('YPK', 'Pitt Meadows', 'Pitt Meadows Airport', 2, '49°12′58″N122°42′36″W', 1524, 'junco'),
('YPR', 'Prince Rupert', 'Prince Rupert Airport', 6, '54°17′10″N130°26′41″W', 1829, 'kite'),
('YPU', 'Puntzi Mountain', 'Puntzi Mountain Airport', 5, '52°06′46″N124°08′41″W', 1832, ''),
('YPW', 'Powell River', 'Powell River Airport', 2, '49°50′03″N124°30′01″W', 1104, 'loon'),
('YPZ', 'Burns Lake', 'Burns Lake Airport', 6, '54°22′35″N125°57′05″W', 1542, ''),
('YQQ', 'Comox', 'CFB Comox (Comox Airport)', 1, '49°42′39″N124°53′12″W', 3048, ''),
('YQZ', 'Quesnel', 'Quesnel Airport', 5, '53°01′34″N122°30′37″W', 1677, 'magpie'),
('YRV', 'Revelstoke', 'Revelstoke Airport', 3, '50°57′44″N118°11′04″W', 1571, 'nuthatch'),
('YSE', 'Squamish', 'Squamish Airport', 2, '49°46′54″N123°09′43″W', 732, ''),
('YSN', 'Salmon Arm', 'Salmon Arm Airport', 3, '50°40′58″N119°13′43″W', 1299, 'owl'),
('YVE', 'Vernon', 'Vernon Regional Airport', 8, '50°14′46″N119°19′51″W', 1072, ''),
('YVR', 'Vancouver', 'Vancouver International Airport', 2, '49°11′41″N123°11′02″W', 3505, 'pelican'),
('YWL', 'Williams Lake', 'Williams Lake Airport', 5, '52°11′00″N122°03′16″W', 2134, ''),
('YXC', 'Cranbrook', 'Cranbrook/Canadian Rockies International Airport', 4, '49°36′44″N115°46′55″W', 2438, 'quail'),
('YXJ', 'Fort St. John', 'Fort St. John Airport (North Peace Airport)', 9, '56°14′17″N120°44′25″W', 2106, ''),
('YXS', 'Prince George', 'Prince George Airport', 7, '53°53′03″N122°40′39″W', 3490, 'raven'),
('YXT', 'Terrace/Kitimat', 'Northwest Regional Airport Terrace-Kitimat (Terrace Airport)', 6, '54°28′07″N128°34′42″W', 2285, 'swallow'),
('YXX', 'Abbotsford', 'Abbotsford International Airport', 2, '49°01′31″N122°21′38″W', 2925, 'thrush'),
('YYD', 'Smithers', 'Smithers Airport', 6, '54°49′31″N127°10′58″W', 2299, 'unlikely'),
('YYE', 'Fort Nelson', 'Fort Nelson Airport', 9, '58°50′11″N122°35′49″W', 1951, 'vulture'),
('YYF', 'Penticton', 'Penticton Regional Airport', 8, '49°27′45″N119°36′08″W', 1829, 'warbler'),
('YYJ', 'Victoria', 'Victoria International Airport', 1, '48°38′49″N123°25′33″W', 2133, 'xwing'),
('YZP', 'Sandspit', 'Sandspit Airport', 6, '53°15′15″N131°48′50″W', 1558, ''),
('YZT', 'Port Hardy', 'Port Hardy Airport', 1, '50°40′50″N127°22′00″W', 1524, ''),
('YZY', 'Mackenzie', 'Mackenzie Airport', 7, '55°17′58″N123°08′00″W', 1534, 'yellowhammer'),
('ZEL', 'Bella Bella', 'Denny Island Aerodrome', 5, '52°08′23″N128°03′49″W', 900, ''),
('ZGF', 'Grand Forks', 'Grand Forks Airport', 8, '49°00′56″N118°25′50″W', 1314, ''),
('ZMH', '108 Mile Ranch', 'South Cariboo Regional Airport (108 Mile Ranch Airport)', 3, '51°44′10″N121°19′58″W', 1613, 'zipper'),
('ZMT', 'Masset', 'Masset Airport', 6, '54°01′38″N132°07′30″W', 1501, ''),
('ZST', 'Stewart', 'Stewart Aerodrome', 6, '55°56′00″N129°59′00″W', 1189, '');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('kl245fm30151oc7nq203j7o8th6gsc79', '127.0.0.1', 1504767307, 0x5f5f63695f6c6173745f726567656e65726174657c693a313530343736373330373b),
('2ueuqpmv4m0116vqjaloiuf58g51asau', '127.0.0.1', 1505491944, 0x5f5f63695f6c6173745f726567656e65726174657c693a313530353439313934343b),
('8shou5jfec1c8luh14p8fj3l1gsfbjeb', '127.0.0.1', 1505491944, 0x5f5f63695f6c6173745f726567656e65726174657c693a313530353439313934343b),
('c8scbqoru2jrhfidavndungsmkv6aceh', '127.0.0.1', 1506240935, 0x5f5f63695f6c6173745f726567656e65726174657c693a313530363234303638353b);

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE `properties` (
  `id` varchar(16) NOT NULL,
  `value` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `value`) VALUES
('alarm', '1460659500'),
('ante', '2000'),
('next_event', '0'),
('potd', 'mustard'),
('priceperpack', '100'),
('round', '31'),
('startcash', '1000'),
('state', '3'),
('zulu', '2017-04-05 14:31:39.');

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `anchor` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `anchor`) VALUES
(1, 'Vancouver Island', 'YCD'),
(2, 'Lower Mainland', 'YDT'),
(3, 'Thompson-Nicola', 'YKA'),
(4, 'Kootenay', 'YXC'),
(5, 'Cariboo', 'YWL'),
(6, 'Skeena', 'YYD'),
(7, 'Omineca', 'YXS'),
(8, 'Okanagan', 'YYF'),
(9, 'Peace', 'YXJ');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE `teams` (
  `id` varchar(20) NOT NULL,
  `token` varchar(128) NOT NULL,
  `org` varchar(128) NOT NULL,
  `repo` varchar(128) NOT NULL,
  `branch` varchar(128) NOT NULL,
  `website` varchar(128) NOT NULL,
  `base` varchar(128) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `token`, `org`, `repo`, `branch`, `website`, `base`, `updated`) VALUES
('albatros', '1b623b', '', '', 'develop', '', 'comp4711', '2017-04-05 00:34:37'),
('bluebird', '3ab791', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:32'),
('cuckoo', '4bd17e', '', '', 'develop', '', 'comp4711', '2017-04-01 17:29:17'),
('dove', '268a1e', '', '', 'develop', '', 'comp4711', '2017-04-26 17:15:46'),
('eagle', '2e9a63', '', '', 'develop', '', 'comp4711', '2017-02-09 11:18:06'),
('falcon', '16525a', '', '', 'develop', '', 'comp4711', '2017-04-03 18:37:02'),
('goose', '1e50e6', '', '', 'develop', '', 'comp4711', '2017-04-02 20:39:00'),
('heron', '40a22d', '', '', 'develop', '', 'comp4711', '2017-02-09 11:18:06'),
('ibis', '1f6641', '', '', 'develop', '', 'comp4711', '2017-04-03 11:43:40'),
('junco', '49b2d0', '', '', 'develop', '', 'comp4711', '2017-03-30 08:45:49'),
('kite', '1d4131', '', '', 'develop', '', 'comp4711', '2017-04-03 22:42:45'),
('loon', '19c2b3', '', '', 'develop', '', 'comp4711', '2017-04-05 22:10:01'),
('magpie', '35a437', '', '', 'develop', '', 'comp4711', '2017-04-02 19:38:33'),
('nuthatch', '13940c', '', '', 'develop', '', 'comp4711', '2017-04-11 16:54:49'),
('owl', '3381b7', '', '', 'develop', '', 'comp4711', '2017-04-02 17:05:17'),
('pelican', '438f06', '', '', 'develop', '', 'comp4711', '2017-03-25 11:34:10'),
('quail', '10a695', '', '', 'develop', '', 'comp4711', '2017-04-03 13:40:11'),
('raven', '256c60', '', '', 'develop', '', 'comp4711', '2017-04-02 17:27:54'),
('swallow', '22a6b9', '', '', 'develop', '', 'comp4711', '2017-04-06 17:25:18'),
('thrush', '3cd865', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('unlikely', '32740f', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('vulture', '41934b', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('warbler', '4c1d57', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('xwing', '3a5850', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('yellowhammer', '1caa0e', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23'),
('zipper', '480a44', '', '', 'develop', '', 'comp4711', '2017-04-02 17:30:23');

-- --------------------------------------------------------

--
-- Table structure for table `websites`
--

DROP TABLE IF EXISTS `websites`;
CREATE TABLE `websites` (
  `id` varchar(20) NOT NULL,
  `token` varchar(128) NOT NULL,
  `org` varchar(128) NOT NULL,
  `repo` varchar(128) NOT NULL,
  `branch` varchar(128) NOT NULL,
  `website` varchar(128) NOT NULL,
  `base` varchar(128) NOT NULL,
  `db` varchar(10) NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pushed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deployed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `websites`
--

INSERT INTO `websites` (`id`, `token`, `org`, `repo`, `branch`, `website`, `base`, `db`, `updated`, `pushed`, `deployed`) VALUES
('acit2910', 'This is not reproducible using the UI', 'jedi-academy', 'learn-2910', 'master', 'acit2910.jlparry.com', 'public_html', '', '2017-02-13 11:16:29', '2017-02-13 11:16:29', '2017-02-13 11:16:29'),
('comp4711', 'This is not reproducible using the UI', 'jedi-academy', 'learn-4711', 'master', 'comp4711.jlparry.com', 'public_html', '', '2017-02-13 11:16:29', '2017-02-13 11:16:29', '2017-02-13 11:16:29'),
('testing', 'blah-blah', 'jim-parry', 'server-test', 'master', '', 'comp4711', '', '2017-02-13 00:50:45', '2017-02-13 00:50:45', '2017-02-13 00:50:45'),
('umbrella', '$2y$10$hYgFjoHfVvUl7jRJv3kP/.3YV/zGlLGKSqxMfBfdPqDG/tvUhzPdi', 'jedi-academy', 'umbrella', 'master', '', 'public_html', 'panda', '2017-02-09 11:15:28', '2017-02-09 11:15:28', '2017-02-09 11:15:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airlines`
--
ALTER TABLE `airlines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `airplanes`
--
ALTER TABLE `airplanes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `airports`
--
ALTER TABLE `airports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `websites`
--
ALTER TABLE `websites`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
